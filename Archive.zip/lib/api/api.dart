import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/family_model.dart';
import '../model/member_model.dart';
import '../model/request_form_model.dart';

class Api{

  static const String baseUrl = "http://localhost:3001"; // Replace with your server URL

  static Future<void> addRequestForm(RequestFormModel requestData) async {
    final url = Uri.parse('$baseUrl/add-request');
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestData),
      );

      if (response.statusCode == 200) {
        print("Data inserted successfully: ${response.body}");
      } else {
        print("Failed to insert data: ${response.statusCode}");
        print("Error: ${response.body}");
      }
    } catch (e) {
      print("Error occurred: $e");
    }
  }

  // API call function
  static Future<UserProfile?> fetchUserProfile(String itsId) async {
    final String baseUrl1 = '$baseUrl/get-profile'; // Replace with your server URL
    final Uri url = Uri.parse('$baseUrl1/$itsId');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = json.decode(response.body);
        return UserProfile.fromJson(jsonResponse);
      } else {
        print("Failed to load profile: ${response.statusCode}");
        return null;
      }
    } catch (e) {
      print("Error occurred: $e");
      return null;
    }
  }

  // Function to fetch family profile
  static Future<Family?> fetchFamilyProfile(String itsId) async {
    final String baseUrl = 'http://localhost:3001/get-family-profile'; // Replace with your Node.js server URL
    final Uri url = Uri.parse('$baseUrl/$itsId');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = json.decode(response.body);
        print(jsonResponse);
        return Family.fromJson(jsonResponse);
      } else {
        print("Failed to load family profile: ${response.statusCode}");
        return null;
      }
    } catch (e) {
      print("Error occurred: $e");
      return null;
    }
  }

}