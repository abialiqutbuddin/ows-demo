import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class RequestTable extends StatefulWidget {
  @override
  _RequestTableState createState() => _RequestTableState();
}

class _RequestTableState extends State<RequestTable> {
  List<Map<String, dynamic>> _data = [];
  final TextEditingController _searchController = TextEditingController();

  Future<void> fetchData({String? id}) async {
    final url = Uri.parse('http://localhost:3000/get-requests${id != null ? "?id=$id" : ""}');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          _data = List<Map<String, dynamic>>.from(jsonDecode(response.body));
        });
      } else {
        print('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching data: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData(); // Fetch all data initially
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request Table'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      labelText: 'Search by ID',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    final id = _searchController.text.trim();
                    if (id.isNotEmpty) {
                      fetchData(id: id);
                    } else {
                      fetchData(); // Fetch all if search is empty
                    }
                  },
                  child: Text('Search'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('ID')),
                    DataColumn(label: Text('Class Degree')),
                    DataColumn(label: Text('Institution')),
                    DataColumn(label: Text('City')),
                    DataColumn(label: Text('Study')),
                    DataColumn(label: Text('Subject')),
                    DataColumn(label: Text('Year')),
                    DataColumn(label: Text('Email')),
                    DataColumn(label: Text('Phone')),
                    DataColumn(label: Text('WhatsApp')),
                    DataColumn(label: Text('Funds')),
                    DataColumn(label: Text('Description')),
                  ],
                  rows: _data.map((item) {
                    return DataRow(cells: [
                      DataCell(Text(item['id'].toString())),
                      DataCell(Text(item['classDegree'] ?? '')),
                      DataCell(Text(item['institution'] ?? '')),
                      DataCell(Text(item['city'] ?? '')),
                      DataCell(Text(item['study'] ?? '')),
                      DataCell(Text(item['subject'] ?? '')),
                      DataCell(Text(item['year'] ?? '')),
                      DataCell(Text(item['email'] ?? '')),
                      DataCell(Text(item['phoneNumber'] ?? '')),
                      DataCell(Text(item['whatsappNumber'] ?? '')),
                      DataCell(Text(item['fundAmount'].toString())),
                      DataCell(Text(item['fundDescription'] ?? '')),
                    ]);
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}