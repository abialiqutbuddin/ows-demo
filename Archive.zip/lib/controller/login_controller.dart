import 'package:ows/api/api.dart';
import 'package:ows/controller/state_management/state_manager.dart';
import 'package:get/get.dart';

import '../constants/dummy_data.dart';
import '../model/family_model.dart';
import '../web_ui/family_screen.dart';

class LoginLogic {

  final StateController stateController = Get.put(StateController());
  // Perform login logic
  Future<void> performLogin() async {
    stateController.toggleLoading(true); // Start loading
    await Future.delayed(const Duration(seconds: 2)); // Simulate a delay
    stateController.toggleLoading(false); // Stop loading
    print('Login performed!');

    Family family = Family();
    Get.to(() => FamilyScreen(family: dummyFamily));
  }

  // Fetch family data and navigate to FamilyScreen
  Future<void> fetchAndNavigate(String itsId) async {
    stateController.toggleLoading(true); // Start loading
    try {
      Family? family = await Api.fetchFamilyProfile(itsId);
      stateController.toggleLoading(false); // Stop loading

      if (family != null) {
        Get.to(() => FamilyScreen(family: family));
      } else {
        Get.snackbar("Error", "No family data found for ITS ID: $itsId");
      }
    } catch (e) {
      stateController.toggleLoading(false); // Stop loading
      Get.snackbar("Error", "Failed to fetch family data: $e");
    }
  }
}