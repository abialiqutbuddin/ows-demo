import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:ows/model/member_model.dart';
import 'package:ows/constants/constants.dart';
import 'package:ows/model/request_form_model.dart';
import 'package:http/http.dart' as http;
import '../api/api.dart';
import 'package:get/get.dart';

class RequestForm extends StatefulWidget {
  final UserProfile member;
  const RequestForm({super.key, required this.member});

  @override
  RequestFormState createState() => RequestFormState();
}

class RequestFormState extends State<RequestForm> {
  final double defSpacing = 8;
  late final UserProfile member;

  bool loading = false;

  final TextEditingController classDegreeController = TextEditingController();
  final TextEditingController institutionController = TextEditingController();
  final TextEditingController studyController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();
  final TextEditingController yearController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController whatsappController = TextEditingController();
  final TextEditingController fundsController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // Dropdown values
  String selectedCity = "Select City";
  String selectedSubject = "Select Subject";

  // Dropdown options
  final List<String> cities = ["Select City", "Karachi", "Islamabad", "Lahore"];
  final List<String> subjects = [
    "Select Subject",
    "Math",
    "Science",
    "History",
    "Computer Science"
  ];

  @override
  void initState() {
    super.initState();
    member = widget.member;
  }

  int calculateAge(String dobString) {
    // Parse the string into a DateTime object
    final dob = DateTime.parse(dobString);
    final today = DateTime.now();
    int age = today.year - dob.year;
    // Adjust age if the current date is before the birthday this year
    if (today.month < dob.month ||
        (today.month == dob.month && today.day < dob.day)) {
      age--;
    }
    return age;
  }

  @override
  void dispose() {
    classDegreeController.dispose();
    institutionController.dispose();
    studyController.dispose();
    yearController.dispose();
    emailController.dispose();
    phoneController.dispose();
    whatsappController.dispose();
    fundsController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    // Define the minimum width for your content
    const double minWidth = 1280;

    // Determine whether the screen is narrower than your minimum width
    final bool isScreenNarrow = screenWidth < minWidth;

    // Wrap your content in a SingleChildScrollView if the screen is too narrow
    Widget content = isScreenNarrow
        ? SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SizedBox(width: minWidth, child: buildContent(context)),
          )
        : buildContent(context);

    return Scaffold(
      backgroundColor: Color(0xfffffcf6),
      body: SingleChildScrollView(
        child: SizedBox(
          child: content,
        ),
      ),
    );
  }

  Widget buildContent(BuildContext context) {
    return Column(
      spacing: 10,
      children: [
        headerSection(context),
        headerProfile(context),
        requestForm(context),
      ],
    );
  }

  Widget headerSection(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(color: Color(0xffdbbb99)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Constants().heading('Profile Preview'),
          Row(
            spacing: 16,
            children: [
              SizedBox(
                width: 120,
                height: 35,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF008759),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    onPressed: () {
                      Get.to(() => RequestTable());
                    },
                    child: Text(
                      "Table",
                      style: TextStyle(color: Colors.white),
                    )),
              ),
              Icon(Icons.close)
            ],
          )
        ],
      ),
    );
  }

  Widget headerProfile(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15),
      margin: EdgeInsets.all(15),
      decoration: BoxDecoration(
          color: Color(0xfffff7ec),
          borderRadius: BorderRadius.all(Radius.circular(5))),
      child: Column(
        spacing: 10,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Constants().heading("Personal Information"),
          Divider(),
          Row(
            children: [
              // Container(
              //   width: 120,
              //     height: 170,
              //     child: Image.asset('assets/img.png',fit: BoxFit.contain,)
              // ),
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: Image.network(
                  'http://localhost:3001/fetch-image?url=${Uri.encodeComponent(member.imageUrl!)}',
                  width: 100,
                  fit: BoxFit.cover,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Column(
                  spacing: 10,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(

                          member.fullName ?? '',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(' | '),
                        Text(member.itsId.toString())
                      ],
                    ),
                    Row(
                      spacing: defSpacing,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.location_on_rounded),
                            Text(member.address ?? ''),
                          ],
                        ),
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.location_on_rounded),
                            Text(
                              member.jamiaat ?? '',
                            ),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      spacing: defSpacing,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.calendar_month_rounded),
                            Text(member.dob ?? ''),
                          ],
                        ),
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.calendar_month_rounded),
                            Text("${calculateAge(member.dob ?? '')} years old"),
                          ],
                        ),
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.email),
                            Text(member.email!),
                          ],
                        ),
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.phone),
                            Text(member.mobileNo!),
                          ],
                        ),
                        Row(
                          spacing: defSpacing,
                          children: [
                            Icon(Icons.phone),
                            Text(member.whatsappNo!),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  spacing: 15,
                  children: [
                    profileBox('Applied By', '30445124', context),
                    profileBox('Name', 'Abi Ali Qutbuddin', context),
                  ],
                ),
              )
            ],
          ),
          lastEducation()
        ],
      ),
    );
  }

  Widget lastEducation() {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: Column(
        spacing: 5,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Constants().heading("Last Education"),
          Divider(),
          Column(
            spacing: 20,
            children: [
              Row(
                spacing: 50,
                children: [
                  Row(
                    children: [
                      Text("Class/ Degree Program: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].className!,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Institution: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].institute!,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Field of Study: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].subject!,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("City: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].city!,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                spacing: 50,
                children: [
                  Row(
                    children: [
                      Text("Subject: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].subject!,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Year: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].endDate.toString(),
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("Grade: ",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        member.education![0].standard!,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Constants().green),
                      ),
                    ],
                  ),
                ],
              )
            ],
          )
        ],
      ),
    );
  }

  Widget profileBox(String title, String value, BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.all(10),
      width: Constants().responsiveWidth(context, 0.12),
      height: 80,
      decoration: BoxDecoration(
          color: Color(0xffffead1),
          borderRadius: BorderRadius.all(Radius.circular(5))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        spacing: 15,
        children: [
          Text(title,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          Text(value,
              style: TextStyle(
                  color: Constants().green, fontWeight: FontWeight.bold))
        ],
      ),
    );
  }

  Widget requestForm(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15),
      margin: EdgeInsets.all(15),
      decoration: BoxDecoration(
          color: Color(0xfffff7ec),
          borderRadius: BorderRadius.all(Radius.circular(5))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        spacing: 10,
        children: [
          Constants().heading('Request for Education Assistance'),
          Divider(),
          Row(
            spacing: 10,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text("Request #: 495262"),
              Text("|"),
              Text(
                  "Date: ${DateTime.now().year}-${DateTime.now().month}-${DateTime.now().day}")
            ],
          ),
          // _form(),
          // _formFunds()
          Form(
            key: _formKey,
            child: Column(
              children: [
                _form(), // First section
                const SizedBox(height: 16),
                _formFunds(), // Funds section
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Define validation logic here
  String? _validateField(String label, String? value) {
    if (value == null || value.isEmpty) {
      return "$label is required";
    }

    if (label.toLowerCase() == "city" && value == "Select City") {
      return "Please select a valid city";
    }

    switch (label.toLowerCase()) {
      case "year":
        return _validateYear(value);
      case "email":
        return _validateEmail(value);
      case "phone number":
      case "whatsapp number":
        return _validatePhoneNumber(value);
      case "funds":
        return _validateFunds(value);
      default:
        return null;
    }
  }

  String? _validateYear(String value) {
    if (!RegExp(r'^\d{4}$').hasMatch(value)) {
      return "Enter a valid year (e.g., 2023)";
    }
    return null;
  }

  String? _validateEmail(String value) {
    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
      return "Enter a valid email address";
    }
    return null;
  }

  String? _validatePhoneNumber(String value) {
    if (!RegExp(r'^\+?\d{10,15}$').hasMatch(value)) {
      return "Enter a valid phone number (10-15 digits)";
    }
    return null;
  }

  String? _validateFunds(String value) {
    if (!RegExp(r'^\d+$').hasMatch(value)) {
      return "Enter a valid numeric amount for funds";
    }
    return null;
  }

  Widget _buildField(String label, TextEditingController controller, {double? height}) {
    bool isDescription = height != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        SizedBox(
          height: height ?? 40,
          child: TextFormField(
            controller: controller,
            maxLines: isDescription ? 3 : 1,
            decoration: InputDecoration(
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide.none, // Removes the border
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide.none, // No border when focused
              ),
              filled: true,
              fillColor: const Color(0xfffffcf6),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            ),
            validator: (value) => _validateField(label, value),
          ),
        ),
      ],
    );
  }

// Wrap the form sections inside a `Form` widget
  Widget _form() {
    return Form(
      key: _formKey,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xffffead1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Flexible(child: _buildField("Class / Degree Program", classDegreeController)),
                Flexible(child: _buildField("Institution", institutionController)),
                Flexible(
                  child: _buildDropdown("City", selectedCity, cities, (newValue) {
                    setState(() {
                      selectedCity = newValue!;
                    });
                  }),
                ),
                Flexible(child: _buildField("Study", studyController)),
                Flexible(
                  child: _buildDropdown("Subject / Course", selectedSubject, subjects, (newValue) {
                    setState(() {
                      selectedSubject = newValue!;
                    });
                  }),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Flexible(child: _buildField("Year", yearController)),
                Flexible(child: _buildField("Email", emailController)),
                Flexible(child: _buildField("Phone Number", phoneController)),
                Flexible(child: _buildField("WhatsApp Number", whatsappController)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _formFunds() {
    return Form(
      key: _formKey,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xffffead1),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Flexible(flex: 2, child: _buildField("Funds", fundsController)),
                Flexible(
                  flex: 5,
                  child: _buildField("Description", descriptionController, height: 100),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: 120,
              height: 35,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF008759),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
                onPressed: () async {
                  setState(() {
                    loading = true;
                  });
                  if (_formKey.currentState!.validate()) {
                    var newData = RequestFormModel(
                      classDegree: classDegreeController.text,
                      institution: institutionController.text,
                      city: selectedCity,
                      study: studyController.text,
                      subject: selectedSubject,
                      year: yearController.text,
                      email: emailController.text,
                      phoneNumber: phoneController.text,
                      whatsappNumber: whatsappController.text,
                      fundAmount: fundsController.text,
                      memberITS: member.itsId.toString(),
                      appliedby: member.itsId.toString(),
                      fundDescription: descriptionController.text,
                      mohalla: member.jamaatId.toString(),
                      address: member.address ?? "",
                      dob: member.dob ?? "",
                      fullName: member.fullName ?? "",
                      firstName: member.firstName ?? "",
                      applyDate: DateTime.now().toString(),
                    );

                    // Call the API to add request
                    await Api.addRequestForm(newData);
                  }
                  setState(() {
                    loading = false;
                  });
                },
                child: loading
                    ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                    SizedBox(width: 8),
                    Text(
                      "Loading...",
                      style: TextStyle(color: Colors.white),
                    ),
                  ],
                )
                    : const Text(
                  "Request",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  // Helper method for dropdowns
  Widget _buildDropdown(String label, String selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Column(
      spacing: 5,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(
          height: 40,
          child: DropdownButtonFormField<String>(
            value: selectedValue,
            icon: const Icon(Icons.arrow_drop_down),
            decoration: InputDecoration(
              filled: true,
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide.none, // Removes the border
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide.none, // No border when focused
              ),
              fillColor: const Color(0xfffffcf6), // Background color
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(
                  horizontal: 10, vertical: 0),
            ),
            items: items.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

class RequestTable extends StatefulWidget {
  @override
  _RequestTableState createState() => _RequestTableState();
}

class _RequestTableState extends State<RequestTable> {
  List<Map<String, dynamic>> _data = [];
  final TextEditingController _searchController = TextEditingController();

  Future<void> fetchData({String? id}) async {
    final url = Uri.parse('http://localhost:3000/get-requests${id != null ? "?id=$id" : ""}');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          _data = List<Map<String, dynamic>>.from(jsonDecode(response.body));
        });
      } else {
        print('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching data: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData(); // Fetch all data initially
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request Table'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      labelText: 'Search by ID',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    final id = _searchController.text.trim();
                    if (id.isNotEmpty) {
                      fetchData(id: id);
                    } else {
                      fetchData(); // Fetch all if search is empty
                    }
                  },
                  child: Text('Search'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('ID')),
                    DataColumn(label: Text('Class Degree')),
                    DataColumn(label: Text('Institution')),
                    DataColumn(label: Text('City')),
                    DataColumn(label: Text('Study')),
                    DataColumn(label: Text('Subject')),
                    DataColumn(label: Text('Year')),
                    DataColumn(label: Text('Email')),
                    DataColumn(label: Text('Phone')),
                    DataColumn(label: Text('WhatsApp')),
                    DataColumn(label: Text('Funds')),
                    DataColumn(label: Text('Description')),
                  ],
                  rows: _data.map((item) {
                    return DataRow(cells: [
                      DataCell(Text(item['id'].toString())),
                      DataCell(Text(item['classDegree'] ?? '')),
                      DataCell(Text(item['institution'] ?? '')),
                      DataCell(Text(item['city'] ?? '')),
                      DataCell(Text(item['study'] ?? '')),
                      DataCell(Text(item['subject'] ?? '')),
                      DataCell(Text(item['year'] ?? '')),
                      DataCell(Text(item['email'] ?? '')),
                      DataCell(Text(item['phoneNumber'] ?? '')),
                      DataCell(Text(item['whatsappNumber'] ?? '')),
                      DataCell(Text(item['fundAmount'].toString())),
                      DataCell(Text(item['fundDescription'] ?? '')),
                    ]);
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}